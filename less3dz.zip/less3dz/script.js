const variableFirst = +prompt('Hello!Please enter a number (variable - a)');
const variableSecond = +prompt('Please enter the second number (vareable - b)');
const operator = prompt('Please enter sign +, -, *, /');

const sum = calcSum(variableFirst, variableSecond);
const deff = calcDefference(variableFirst, variableSecond);
const div = calcDivision(variableFirst, variableSecond);
const mult = calcMultiplication(variableFirst, variableSecond);

switch(operator) {
    case '+': alert(sum);break;
    case '-': alert(deff);break;
    case '/': alert(div);break;
    case '*': alert(mult);break;
}
// Или так

// if (operator == '+') {
//     alert(sum);
// } else if (operator == '-') {
//     alert(deff);
// } else if (operator == '/') {
//     alert(div);
// } else alert(mult);


function calcSum(a, b) {
    const result = a + b;
    return (`${a} + ${b} = ${a + b}`);
}

function calcDefference(a, b) {
    const result = a - b;
    return (`${a} - ${b} = ${a - b}`);
}

function calcDivision(a, b) {
    const result = a / b;
    return (`${a} / ${b} = ${a / b}`);
}

function calcMultiplication(a, b) {
    const result = a * b;
    return  (`${a} * ${b} = ${a * b}`);
}